package test;

public class MainException extends Exception{
	public MainException(String errMsg) {
		super(errMsg);
		System.out.println(errMsg);
	}
}
