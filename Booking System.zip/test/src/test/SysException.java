package test;

public class SysException extends Exception{
	
	public SysException(String errMsg) {
		super(errMsg);
		System.out.println(errMsg);
	}
	
}
