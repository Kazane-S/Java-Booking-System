package test;



public class RentalProperty {
String propertyID;
int streetnumber;
String streetname;
String suburb;
int nofbed;
String propertyType;
String propertyStatus;
public RentalProperty(){
	propertyID="";
	streetnumber=0;
	streetname="";
	suburb="";
	nofbed=0;
	propertyType="";
	propertyStatus="";
	
}
public RentalProperty(String id,int sno,String sname,String sub,int beds,String ptype,String status){
	propertyID=id;
	streetnumber=sno;
	streetname=sname;
	suburb=sub;
	nofbed=beds;
	propertyType=ptype;
	propertyStatus=status;
	
	
}
public void rent(String cus, DateTime d, int days) throws RentException {}

public void returnProperty(DateTime d) throws ReturnException {}

public void performMaintenance() {}

public void completeMaintenance(DateTime completionDate) throws MainException  {}

public String getDetails() {
	return null;
}
}
