package test;

public class ReturnException extends Exception{
	public ReturnException(String errMsg) {
		super(errMsg);
		System.out.println(errMsg);
	}
}
