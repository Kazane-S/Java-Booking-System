package test;
import java.io.BufferedReader;
import java.io.FileReader;

import hsql_db.*;
import view.*;

public class startup {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
//		HSQLAccess ha = new HSQLAccess();
//		ha.HSQLAccess2();
		ConnectionTest ct0 = new ConnectionTest();
		ct0.ConnectionTest2();		
		DeleteTable dt = new DeleteTable();
		dt.DeleteTable2();
		CreateTable ct = new CreateTable();
		ct.CreateTable2();
		InsertRow ir = new InsertRow();
		ir.InsertInitialRows();
		
		FlexiRentSystem fe=new FlexiRentSystem();
	}
}
