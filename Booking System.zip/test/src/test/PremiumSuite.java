package test;


public class PremiumSuite  extends RentalProperty {
	
	// define default variables
	// premiumsuite data is recorded in array
	RentalRecord prearr[];
	int count;
	DateTime Maincomplete;
	
	public PremiumSuite(String pid,int snum,String sname,String sub,int numbeds,String ptype,String pstatus){
		// call variables from rentalproperty
		super(pid,snum,sname,sub,3,ptype,pstatus);
		
		// make 10 arrays
		prearr=new RentalRecord[10];
		count=0;
	}
	
	public void rent(String custid, DateTime rentDate, int numOfRentDay) throws RentException	
	// rent(String customerID, DateTime rentdate, Int numOfRentDay) [boolean]
	{
		
		String recordid=rentDate.getEightDigitDate();
		this.propertyStatus="rented";
		RentalRecord rrecord=new RentalRecord(recordid,rentDate,numOfRentDay);
		
		// methods of shifting to right array
		// when arrays are full
		if(count==10)
		{
			// for arrays 0 to 8
			for(int i=0;i<9;i++)
			{
				// push one array to next array
				prearr[i+1]=prearr[i];
			}
			
			// first array is new record
			prearr[0]=rrecord;
		}
		
		// when array is not full
		else{		
			// iteration through the arrays that are used
			for(int i=0;i<count;i++)
			{
				// push one array to next array
				prearr[i+1]=prearr[i];
			}
			
			// track number of arrays
			count += 1;
			
			// first array indicated to new record
			prearr[0]=rrecord;
		}
	}
	
	
	public void returnProperty(DateTime returnDate) throws ReturnException {
		
		// calculate date differences to see late or not
		int diffd=DateTime.diffDays(returnDate,prearr[0].rentDate);
		
		
		// if the date is different
		if(diffd>=0)
		{
			
			// property becomes available
			System.out.println(propertyType+" "+this.propertyID+" is returned at "+returnDate);
			propertyStatus="available";
			prearr[0].ActualReturnDate = returnDate;
			
			// check if the return date is late
			int late=DateTime.diffDays(returnDate,prearr[0].EstimatedReturnDate);
			
			// calculate rental fee
			prearr[0].rentalfee=554*diffd;
			
			// not late
			if(late<=0)
			{
				prearr[0].latefee=0;
			}
			
			// late
			else
			{
				prearr[0].latefee=late*662;
			}
		}
	}
	
	public void ireturnProperty(DateTime returnDate) throws ReturnException {
		
		// calculate date differences to see late or not
		int diffd=DateTime.diffDays(returnDate,prearr[0].rentDate);
		
		
		// if the date is different
		if(diffd>=0)
		{
			
			// property becomes available
			propertyStatus="available";
			prearr[0].ActualReturnDate = returnDate;
			
			// check if the return date is late
			int late=DateTime.diffDays(returnDate,prearr[0].EstimatedReturnDate);
			
			// calculate rental fee
			prearr[0].rentalfee=554*diffd;
			
			// not late
			if(late<=0)
			{
				prearr[0].latefee=0;
			}
			
			// late
			else
			{
				prearr[0].latefee=late*662;
			}
		}
	}
	
	public void performMaintenance() {
		// check property is on rent to have maintenance
		if(propertyStatus.compareToIgnoreCase("rented")!=0)
		{
			// change status to maintenance
			propertyStatus="Maintenance";
			System.out.println(propertyType+" "+this.propertyID+" is now under maintenance");
		}
	}
	
	public void completeMaintenance(DateTime completionDate) throws MainException {
		Maincomplete=completionDate;
		propertyStatus="available";
		System.out.println(propertyType+" "+this.propertyID+" has all maintenance completed and ready for rent");
	}
	
	public String toString(){
		String output="";
		output=propertyID+":"+streetnumber+":"+streetname+":"+suburb+":"+nofbed+":"+propertyType+":"+propertyStatus;
		return output;
	}
	
	public String getDetails(){
		String output="";
		output="Property ID:\t\t"+propertyID+"\n"
				+"Address:\t\t"+streetnumber+" "+streetname+" "+suburb+"\n"
				+"Bedroom:\t\t"+nofbed+"\n"
				+"Type:\t\t"+propertyType+"\n"
				+"Status:\t\t"+propertyStatus+"\n"
				+"Rental Record:\t\t";
		if(count==0)
			output=output+"empty";
		else
		{
			for(int i=0;i<count;i++)
			{
				output=output+"\nRecord ID:\t\t"+prearr[i].recordID+"\n"
						+"Rent Date:\t\t"+prearr[i].rentDate.toString()+"\n"
						+"Estimated Return date:\t\t"+prearr[i].EstimatedReturnDate+"\n"
						+"Actual Return date:\t\t"+prearr[i].ActualReturnDate+"\n"
						+"Renal Fee:\t\t"+prearr[i].rentalfee+"\n"
						+"Late fee:\t\t"+prearr[i].latefee;
				output=output+"\n--------------------------------------------------------------------------\n";
			}
		}
		return output;
	}
}

