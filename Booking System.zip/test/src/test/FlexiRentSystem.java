package test;

import java.io.*;
import java.util.*;
import hsql_db.*;


public class FlexiRentSystem {
	
public FlexiRentSystem() throws Exception
{
	start();
}

public void menu()
{
	System.out.println("**** FLEXIRENT SYSTEM MENU ****\n	Add Property: 1\n	Rent Property: 2\n	Return Property: 3\n	Property Maintenance: 4\n	Complete Maintenance: 5\n	Display All Properties: 6\n	Exit Program: 7\n	Enter your choice:");	
}

public void start() throws Exception{
//	SysException, ReturnException, RentException, MainException
	
	String pid;
	String name;
	int snum;
	String sub;
	int bed;
	String type;
	String status;
	
	Map<String, Apartment> hma = new HashMap<String, Apartment>();
	Map<String, PremiumSuite> hmp = new HashMap<String, PremiumSuite>();
	
//	Insert rows from DB to Array
	try {	
	BufferedReader br = new BufferedReader(new FileReader("myfiles/data.txt"));
	String next = br.readLine();
	
	while(next != null) {
				
		String s[] = next.split(":");
		String s0[] = s[0].split("_");
		
//		inserting property
		
		if(s0.length < 3) {
			pid = s[0];
			snum = Integer.parseInt(s[1]);
			name = s[2];
			sub = s[3];
			type = s[4];
			bed = Integer.parseInt(s[5]);
			status = s[6];
			if(type.compareToIgnoreCase("apartment")==0) {
				hma.put(pid,new Apartment(pid,snum,name,sub,bed,type,status));
			}
			if(type.compareToIgnoreCase("premiumsuite")==0){
				hmp.put(pid,new PremiumSuite(pid,snum,name,sub,bed,type,status));
			}
		}
		
//		inserting record
		
		if(s0.length >3) {
				pid = s0[0] + "_" + s0[1];
				String cus = s0[2] + "_" + s0[3];
				String rntdate[] = s[1].split("/");
				DateTime d=new DateTime(Integer.parseInt(rntdate[0]),Integer.parseInt(rntdate[1]),Integer.parseInt(rntdate[2]));
				String returndate[] = s[2].split("/");
				DateTime f=new DateTime(Integer.parseInt(returndate[0]),Integer.parseInt(returndate[1]),Integer.parseInt(returndate[2]));
				int dif=DateTime.diffDays(f,d);
				String areturndate[] = s[3].split("/");
				DateTime ard=new DateTime(Integer.parseInt(areturndate[0]),Integer.parseInt(areturndate[1]),Integer.parseInt(areturndate[2]));
		
				
				if(hma.containsKey(pid)) {
					Apartment apt = (Apartment) hma.get(pid);
					
					if(apt.propertyStatus.compareToIgnoreCase("available")==0)
					{
						apt.rent(cus,d,dif);
						hma.replace(pid, apt);
						apt.ireturnProperty(ard);
						hma.replace(pid, apt);
					}
					if(apt.propertyStatus.compareToIgnoreCase("rented")==0)
					{
						System.out.println(apt.propertyType+" "+pid+" could not be rented");
					}
				}
				
				if(hmp.containsKey(pid)) {
					PremiumSuite ps = (PremiumSuite) hmp.get(pid);					
					if(ps.propertyStatus.compareToIgnoreCase("available")==0)
					{
						ps.rent(cus,d,dif);
						hmp.replace(pid, ps);
						ps.ireturnProperty(ard);
						hmp.replace(pid, ps);
					}
					if(ps.propertyStatus.compareToIgnoreCase("rented")==0)
					{
						System.out.println(ps.propertyType+" "+pid+" could not be rented");
					}
				}					
		}
			
		next = br.readLine();
	}
	
	br.close();
	}catch (Exception e) {
		System.out.println(e.getMessage());
	}
	
	
	
		
	
	
	int option;
	Scanner sc=new Scanner(System.in);
	
	while(true)
	{
		menu();
		
		try {
		option=Integer.parseInt(sc.nextLine());
		
		
		
		switch(option)
		{
		case 1:
			
//			pid
			
			do {
			System.out.print("\nEnter propertyID: ");
			pid=sc.nextLine();
			if(pid.isEmpty()) {
				System.out.println("Input cannot be Null");
			}
			} while(pid.equals(""));
			
			
//			snum
			
			do {
			System.out.print("\nenter streetNumber: ");
			String inputcheck = sc.nextLine();
			try {
				snum = Integer.parseInt(inputcheck);
				break;
			}
			catch(NumberFormatException e) {
				System.out.println("Input must be an integer!");
			}
			} while (true);
			
			
//			sname
			
			do {
			System.out.print("\nEnter streetName: ");
			name=sc.nextLine();
			if(name.isEmpty()) {
				System.out.println("Input cannot be Null");
			}
			} while (name.equals(""));
			
			
//			sub
			
			do {
			System.out.print("\nenter suburb:");
			sub=sc.nextLine();
			if(sub.isEmpty()) {
				System.out.println("Input cannot be Null");
			}
			} while (sub.equals(""));
			
			
//			type
			
			do {			
			System.out.print("\nenter propertytype:");
			type=sc.nextLine();
			
			if(type.compareToIgnoreCase("apartment")==0) {
				break;
			}
			if(type.compareToIgnoreCase("premiumsuite")==0) {
				break;
			}
			if(type.isEmpty()) {
				System.out.println("Input cannot be Null");
			}
			else {
				System.out.println("Type must be either Apartment/PremiumSuite");
				type="";
			}
			
			} while(type.equals(""));
			
			
//			if apartment
			
			if(type.compareToIgnoreCase("apartment")==0) {
				do {
					System.out.print("\nenter no. of beds:");
					String inputcheck=sc.nextLine();
					try {
						bed=Integer.parseInt(inputcheck);
						break;
					}
					catch(NumberFormatException e){
						System.out.println("Input must be an integer!");
					}
				} while (true);
				
				
				do {
					System.out.print("\nenter propertystatus: ");
					status=sc.nextLine();
					if(status.compareToIgnoreCase("rented")==0) {
						break;
					}
					if(status.compareToIgnoreCase("available")==0) {
						break;
					}
					if(status.compareToIgnoreCase("maintenance")==0) {
						break;
					}
					if(status.isEmpty()) {
						System.out.println("Input cannot be Null");
					}
					else {
						System.out.println("Type must be either Available/Rented/Maintenance");
						status="";
					}
				} while(status.equals(""));
				hma.put(pid,new Apartment(pid,snum,name,sub,bed,type,status));
			}
			
//			if premiumsuite
			
			
			if(type.compareToIgnoreCase("PremiumSuite")==0) {
				do {
					System.out.print("\nenter propertystatus: ");
					status=sc.nextLine();
					if(status.compareToIgnoreCase("rented")==0) {
						break;
					}
					if(status.compareToIgnoreCase("available")==0) {
						break;
					}
					if(status.compareToIgnoreCase("maintenance")==0) {
						break;
					}
					if(status.isEmpty()) {
						System.out.println("Input cannot be Null");
					}
					else {
						System.out.println("Type must be either Available/Rented/Maintenance");
						status="";
					}
				} while(status.equals(""));
				bed = 3;
				hmp.put(pid,new PremiumSuite(pid,snum,name,sub,bed,type,status));
			}			
			break;
			
			
			
		case 2:
			do {
				System.out.println("\nEnter property id:");
				pid=sc.nextLine();
				
				
				int count = 0;
				
				if(hma.containsKey(pid)) {
					Apartment apt = (Apartment) hma.get(pid);
					
					if(apt.propertyStatus.compareToIgnoreCase("available")==0)
					{
						System.out.print("Customer id:");
						String cus=sc.nextLine();
						System.out.println("\nRent date(dd/mm/yyyy):");
						String rntdate=sc.nextLine();
						String s[]=rntdate.split("/");
						System.out.println("How many Days?: ");
						int days=Integer.parseInt(sc.nextLine());
						
						try {						
						DateTime d=new DateTime(Integer.parseInt(s[0]),Integer.parseInt(s[1]),Integer.parseInt(s[2]));
						apt.rent(cus,d,days);
						hma.replace(pid, apt);	
						System.out.println(apt.propertyType+" "+pid+" is now rented by customer "+cus);
						count++;
						break;					
						} catch (NumberFormatException e) {
							System.out.println("Number format Error!");
						}
						
						
					}
					if(apt.propertyStatus.compareToIgnoreCase("rented")==0)
					{
						System.out.println(apt.propertyType+" "+pid+" could not be rented");
						
						count++;
						break;
					}
				}
				
				if(hmp.containsKey(pid)) {
					PremiumSuite ps = (PremiumSuite) hmp.get(pid);					
					if(ps.propertyStatus.compareToIgnoreCase("available")==0)
					{
						System.out.print("Customer id:");
						String cus=sc.nextLine();
						System.out.println("\nRent date(dd/mm/yyyy):");
						String rntdate=sc.nextLine();
						String s[]=rntdate.split("/");
						System.out.println("How many Days?: ");
						int days=Integer.parseInt(sc.nextLine());
						
						try {
						DateTime d=new DateTime(Integer.parseInt(s[0]),Integer.parseInt(s[1]),Integer.parseInt(s[2]));
						ps.rent(cus,d,days);
						hmp.replace(pid, ps);
						System.out.println(ps.propertyType+" "+pid+" is now rented by customer "+cus);
						
						count++;
						break;
						} catch (NumberFormatException e) {
							System.out.println("Number format Error!");
						}
					}
					if(ps.propertyStatus.compareToIgnoreCase("rented")==0)
					{
						System.out.println(ps.propertyType+" "+pid+" could not be rented");
						
						count++;
						break;
					}
				}
				
				if(count == 0) {
					System.out.println("Property " + pid + " " + "does not exist!");
					break;
				}
			} while (!pid.equals(""));
			
			
			break;
			
			
		case 3:
			do {
				System.out.println("\nEnter property id:");
				pid=sc.nextLine();
				int count = 0;
				
				if(hma.containsKey(pid)) {
					Apartment apt = (Apartment) hma.get(pid);
					if(apt.propertyStatus.compareToIgnoreCase("rented")==0)
					{		
						System.out.println("\nReturn date(dd/mm/yyyy):");
						String rntdate=sc.nextLine();
						String s[]=rntdate.split("/");
						
						try {
						DateTime d=new DateTime(Integer.parseInt(s[0]),Integer.parseInt(s[1]),Integer.parseInt(s[2]));
						apt.returnProperty(d);
						hma.replace(pid, apt);
						System.out.println(apt.getDetails());
						
						count++;
						break;
						} catch (NumberFormatException e) {
							System.out.println("Number format Error!");
						}
					}
				}
				
				if(hmp.containsKey(pid)) {
					PremiumSuite ps = (PremiumSuite) hmp.get(pid);					
					if(ps.propertyStatus.compareToIgnoreCase("rented")==0)
					{
						System.out.println("\nReturn date(dd/mm/yyyy):");
						String rntdate=sc.nextLine();
						String s[]=rntdate.split("/");
						
						try {
						DateTime d=new DateTime(Integer.parseInt(s[0]),Integer.parseInt(s[1]),Integer.parseInt(s[2]));
						ps.returnProperty(d);
						hmp.replace(pid, ps);
						System.out.println(ps.getDetails());
						
						count++;
						break;
						} catch (NumberFormatException e) {
							System.out.println("Number format Error!");
						}
					}
				}
				
				if(count == 0) {
					System.out.println("Property " + pid + " " + "does not exist!");
					break;
				}
			} while (!pid.equals(""));
			
			break;
						
			
		case 4:
			do {
				System.out.println("\nEnter property id:");
				pid=sc.nextLine();
				
				int count = 0;
				
				if(hma.containsKey(pid)) {
					Apartment apt = (Apartment) hma.get(pid);
					if(apt.propertyStatus.compareToIgnoreCase("rented") !=0)
					{		
						apt.performMaintenance();
						hma.replace(pid, apt);
						
						count++;
						break;
					}
				}
				
				if(hmp.containsKey(pid)) {
					PremiumSuite ps = (PremiumSuite) hmp.get(pid);					
					if(ps.propertyStatus.compareToIgnoreCase("rented") !=0)
					{
						ps.performMaintenance();
						hmp.replace(pid, ps);

						count++;
						break;
					}					
				}
				
				if(count == 0) {
					System.out.println("Property " + pid + " " + "does not exist!");
					break;
				}
			} while (!pid.equals(""));
			
			break;
			
			
		case 5:
			do {
				System.out.println("\nEnter property id:");
				pid=sc.nextLine();
				
				int count = 0;
				
				if(hma.containsKey(pid)) {
					Apartment apt = (Apartment) hma.get(pid);
					if(apt.propertyStatus.compareToIgnoreCase("maintenance") ==0)
					{	
						System.out.println("\nMaintenance completion date (dd/mm/yyyy):");
						String rntdate=sc.nextLine();
						String s[]=rntdate.split("/");
						
						try {
						DateTime d=new DateTime(Integer.parseInt(s[0]),Integer.parseInt(s[1]),Integer.parseInt(s[2]));
						apt.completeMaintenance(d);
						hma.replace(pid, apt);
						
						count++;
						break;
						} catch (NumberFormatException e) {
							System.out.println("Number format Error!");
						}
					}
				}
				
				if(hmp.containsKey(pid)) {
					PremiumSuite ps = (PremiumSuite) hmp.get(pid);					
					if(ps.propertyStatus.compareToIgnoreCase("maintenance") ==0)
					{
						System.out.println("\nMaintenance completion date (dd/mm/yyyy):");
						String rntdate=sc.nextLine();
						String s[]=rntdate.split("/");
						
						try {
						DateTime d=new DateTime(Integer.parseInt(s[0]),Integer.parseInt(s[1]),Integer.parseInt(s[2]));
						ps.completeMaintenance(d);
						hmp.replace(pid, ps);
						
						count++;
						break;
						} catch (NumberFormatException e) {
							System.out.println("Number format Error!");
						}
					}
				}
				
				if(count == 0) {
					System.out.println("Property " + pid + " " + "does not exist!");
					break;
				}
			} while (!pid.equals(""));
			
			break;
			
		case 6:
			for(String c6 : hma.keySet()) {
				Apartment apt = (Apartment) hma.get(c6);
				System.out.println(apt.getDetails());
			}
			
			for(String c6 : hmp.keySet()) {
				PremiumSuite ps = (PremiumSuite) hmp.get(c6);
				System.out.println(ps.getDetails());
			}
			
			break;
			
		case 7:
			System.exit(0);
			break;
		default:
			System.out.println("Invalid option. Please try again!!!");
		
		}
		} catch(NumberFormatException e) {
			System.out.println("Input must be integer between 1-7");
		}
	}
	}



}