package test;


import java.text.DecimalFormat;


public class RentalRecord {
String recordID;
DateTime rentDate;
DateTime EstimatedReturnDate;
DateTime ActualReturnDate;
double rentalfee;
double latefee;


public RentalRecord(String rid,DateTime rdate,int days){
	recordID=rid;
	rentDate=rdate;
	EstimatedReturnDate=new DateTime(rdate,days);
	ActualReturnDate=null;
	rentalfee=0;
	latefee=0;
}

public String toString(){
	String res="";
	DecimalFormat df = new DecimalFormat("###.##");
	res=recordID+":"+rentDate.toString()+":"+EstimatedReturnDate.toString()+":"+ActualReturnDate+":"+df.format(rentalfee)+":"+df.format(latefee);
	
	return res;
}
public String getDetails(){
	String res="";
	DecimalFormat df = new DecimalFormat("###.##");
	res="Record ID:\t"+recordID+":"+"Rent Date:\t"+rentDate.toString()+":"+"Estimated Return Date: "+EstimatedReturnDate.toString()+":"+"Actual Return Date"+ActualReturnDate+":"+"Rental Fee:\t"+df.format(rentalfee)+":"+"Late Fee:"+df.format(latefee);
	return res;
	
	
}
}
