package test;

public class RentException extends Exception{
	public RentException(String errMsg) {
		super(errMsg);
		System.out.println(errMsg);
	}
}
