package test;


public class Apartment extends RentalProperty {
	RentalRecord arr[];
	int cnt;
	DateTime Maincomplete;
	public Apartment(String id,int sno,String sname,String sub,int beds,String ptype,String status){
		super(id,sno,sname,sub,beds,ptype,status);
		arr=new RentalRecord[10];
		cnt=0;
	}
	public void rent(String customerId, DateTime rentDate, int numOfRentDay) throws RentException
	{
		
	String rid=propertyID+"_"+customerId+"_"+rentDate.getEightDigitDate();
	this.propertyStatus="rented";
	RentalRecord rc=new RentalRecord(rid,rentDate,numOfRentDay);
	if(cnt==10)
	{
		for(int i=0;i<9;i++)
		{
			arr[i+1]=arr[i];
			
		}
		arr[0]=rc;
	}
	else{
		for(int i=0;i<cnt;i++)
		{
			arr[i+1]=arr[i];
			
		}
		cnt++;
		arr[0]=rc;
	}
	
		
	}
	public void returnProperty(DateTime returnDate) throws ReturnException {
		int dif=DateTime.diffDays(returnDate,arr[0].rentDate);
		if(dif>=0)
		{			
			System.out.println(propertyType+" "+this.propertyID+" is returned at "+returnDate);
			propertyStatus="available";
			arr[0].ActualReturnDate = returnDate;
			int late=DateTime.diffDays(returnDate,arr[0].EstimatedReturnDate);
			if(nofbed==1)
				arr[0].rentalfee=143*dif;
			else if(nofbed==2)
				arr[0].rentalfee=210*dif;
			else
				arr[0].rentalfee=319*dif;
			if(late<=0)
			{
				arr[0].latefee=0;
				
			}
			else
			{
				
				if(nofbed==1)
					arr[0].latefee=143*late*115/100;
				else if(nofbed==2)
					arr[0].latefee=210*late*115/100;
				else
					arr[0].latefee=319*late*115/100;
			}
		}
	}
	
	public void ireturnProperty(DateTime returnDate) throws ReturnException {
		int dif=DateTime.diffDays(returnDate,arr[0].rentDate);
		if(dif>=0)
		{			
			propertyStatus="available";
			arr[0].ActualReturnDate = returnDate;
			int late=DateTime.diffDays(returnDate,arr[0].EstimatedReturnDate);
			if(nofbed==1)
				arr[0].rentalfee=143*dif;
			else if(nofbed==2)
				arr[0].rentalfee=210*dif;
			else
				arr[0].rentalfee=319*dif;
			if(late<=0)
			{
				arr[0].latefee=0;
				
			}
			else
			{
				
				if(nofbed==1)
					arr[0].latefee=143*late*115/100;
				else if(nofbed==2)
					arr[0].latefee=210*late*115/100;
				else
					arr[0].latefee=319*late*115/100;
			}
		}
	}
	
	public void performMaintenance() {
		// check property is on rent to have maintenance
		if(propertyStatus.compareToIgnoreCase("rented")!=0)
		{
			// change status to maintenance
			propertyStatus="Maintenance";
			System.out.println(propertyType+" "+this.propertyID+" is now under maintenance");
		}
	}
	
	public void completeMaintenance(DateTime completionDate) throws MainException {
		Maincomplete=completionDate;
		propertyStatus="available";
		System.out.println(propertyType+" "+this.propertyID+" has all maintenance completed and ready for rent");
	}
	
	public String toString(){
		String res="";
		res=propertyID+":"+streetnumber+":"+streetname+":"+suburb+":"+nofbed+":"+propertyType+":"+propertyStatus;
		return res;
	}
	public String getDetails(){
		String res="";
		res="Property ID:\t"+propertyID+"\nAddress:\t"+streetnumber+" "+streetname+" "+suburb+"\nBedroom:\t"+nofbed+"\nType:\t"+propertyType+"\nStatus:\t"+propertyStatus+"\nRental Record:\t";
		if(cnt==0)
			res=res+"empty";
		else
		{
			for(int i=0;i<cnt;i++)
			{
				res=res+"\nRecord ID:\t"+arr[i].recordID+"\nRent Date:\t"+arr[i].rentDate.toString()+"\nEstimated Return date:\t"+arr[i].EstimatedReturnDate+"\nActual Return date:\t"+arr[i].ActualReturnDate+"\nRenal Fee:\t"+arr[i].rentalfee+"\nLate fee:\t"+arr[i].latefee;
				res=res+"\n--------------------------------------------------------------------------\n";
			}
		}
		return res;
	}
}
