package hsql_db;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTable {
	public static void main(String[] args) throws SQLException {
		final String DB_NAME = "testDB";
		final String TABLE_NAME = "DATA";
		final String TABLE_NAME2 = "RECORD";
		
		//use try-with-resources Statement
		try (Connection con = ConnectionTest.getConnection(DB_NAME);
				Statement stmt = con.createStatement();
		) {
			
			int result = stmt.executeUpdate("CREATE TABLE DATA ("
										+ "pid VARCHAR(20) NOT NULL,"
										+ "snum INT NOT NULL,"
										+ "sname VARCHAR(20) NOT NULL,"
										+ "sub VARCHAR(20) NOT NULL,"
										+ "type VARCHAR(20) NOT NULL,"
										+ "bed INT NOT NULL,"
										+ "status VARCHAR(20) NOT NULL,"
										+ "image VARCHAR(30) NOT NULL,"
										+ "description VARCHAR(100) NOT NULL,"
										+ "PRIMARY KEY (pid))");
			if(result == 0) {
				System.out.println("Table " + TABLE_NAME + " has been created successfully");
			} else {
				System.out.println("Table " + TABLE_NAME + " is not created");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
		try (Connection con = ConnectionTest.getConnection(DB_NAME);
				Statement stmt = con.createStatement();
		) {
			
			int result = stmt.executeUpdate("CREATE TABLE RECORD ("
										+ "rid VARCHAR(50) NOT NULL,"
										+ "rdate VARCHAR(20) NOT NULL,"
										+ "erdate VARCHAR(20) NOT NULL,"
										+ "ardate VARCHAR(20) NOT NULL,"
										+ "rfee FLOAT NOT NULL,"
										+ "lfee FLOAT NOT NULL,"
										+ "PRIMARY KEY (rid))");
			if(result == 0) {
				System.out.println("Table " + TABLE_NAME2 + " has been created successfully");
			} else {
				System.out.println("Table " + TABLE_NAME2 + " is not created");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}
	
	public void CreateTable2() {
		final String DB_NAME = "testDB";
		final String TABLE_NAME = "DATA";
		final String TABLE_NAME2 = "RECORD";
		
		//use try-with-resources Statement
		try (Connection con = ConnectionTest.getConnection(DB_NAME);
				Statement stmt = con.createStatement();
		) {
			
			int result = stmt.executeUpdate("CREATE TABLE DATA ("
										+ "pid VARCHAR(20) NOT NULL,"
										+ "snum INT NOT NULL,"
										+ "sname VARCHAR(20) NOT NULL,"
										+ "sub VARCHAR(20) NOT NULL,"
										+ "type VARCHAR(20) NOT NULL,"
										+ "bed INT NOT NULL,"
										+ "status VARCHAR(20) NOT NULL,"
										+ "image VARCHAR(30) NOT NULL,"
										+ "description VARCHAR(100) NOT NULL,"
										+ "PRIMARY KEY (pid))");
			if(result == 0) {
				System.out.println("Table " + TABLE_NAME + " has been created successfully");
			} else {
				System.out.println("Table " + TABLE_NAME + " is not created");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
		try (Connection con = ConnectionTest.getConnection(DB_NAME);
				Statement stmt = con.createStatement();
		) {
			
			int result = stmt.executeUpdate("CREATE TABLE RECORD ("
										+ "rid VARCHAR(50) NOT NULL,"
										+ "rdate VARCHAR(20) NOT NULL,"
										+ "erdate VARCHAR(20) NOT NULL,"
										+ "ardate VARCHAR(20) NOT NULL,"
										+ "rfee FLOAT NOT NULL,"
										+ "lfee FLOAT NOT NULL,"
										+ "PRIMARY KEY (rid))");
			if(result == 0) {
				System.out.println("Table " + TABLE_NAME2 + " has been created successfully");
			} else {
				System.out.println("Table " + TABLE_NAME2 + " is not created");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}
}
