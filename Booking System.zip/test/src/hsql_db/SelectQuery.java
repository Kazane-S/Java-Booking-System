package hsql_db;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SelectQuery {
	public static void main(String[] args) {
		final String DB_NAME = "testDB";
		final String TABLE_NAME = "DATA";
		final String TABLE_NAME2 = "RECORD";
		
		//use try-with-resources Statement
		try (Connection con = ConnectionTest.getConnection(DB_NAME);
				Statement stmt = con.createStatement();
		) {
			String query = "SELECT * FROM " + TABLE_NAME;
			
			try (ResultSet resultSet = stmt.executeQuery(query)) {
				while(resultSet.next()) {

				System.out.printf("pid: %s | snum: %d | sname: %s | sub: %s | type: %s | bed: %d | status: %s | image: %s | description: %s \n",
						resultSet.getString("pid"), resultSet.getInt("snum"), 
						resultSet.getString("sname"), resultSet.getString("sub"),
						resultSet.getString("type"), resultSet.getInt("bed"),
						resultSet.getString("status"), resultSet.getString("image"),
						resultSet.getString("description"));
				}
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
			
			
			String query2 = "SELECT * FROM " + TABLE_NAME2;
			
			try (ResultSet resultSet = stmt.executeQuery(query2)) {
				while(resultSet.next()) {

				System.out.printf("rid: %s | rdate: %s | erdate: %s | ardate: %s | rfee: %f | lfee: %f \n",
						resultSet.getString("rid"), resultSet.getString("rdate"), 
						resultSet.getString("erdate"), resultSet.getString("ardate"),
						resultSet.getFloat("rfee"), resultSet.getFloat("lfee"));
				}
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
