//package hsql_db;
//import java.sql.*;
//
//public class HSQLAccess {
//
//    public static void main(String args[]) throws Exception
//    {
//        Connection con = null;
//        try
//        {
//            Class.forName("org.hsqldb.jdbcDriver");         
//            con = DriverManager.getConnection("jdbc:hsqldb:file:db/sjdb", "sa","");    
//
//            Statement st = con.createStatement();
//            ResultSet rs = st.executeQuery("SELECT * FROM DATA");
//            while(rs.next())
//            {
//                System.out.println(rs.getString(1));
//            }
//
//            con.close();
//
//        }
//        catch(Exception ex )
//        {
//            ex.printStackTrace();
//        }
//        finally
//        {
//            if(con!=null)
//            {
//                 con.close();
//            }
//        }
//    }
//    
//    public void HSQLAccess2() throws Exception {
//    	Connection con = null;
//        try
//        {
//            Class.forName("org.hsqldb.jdbcDriver");         
//            con = DriverManager.getConnection("jdbc:hsqldb:file:db/sjdb", "sa","");    
//
//            Statement st = con.createStatement();
//            ResultSet rs = st.executeQuery("SELECT * FROM CMDS_WO_MASTER");
//            while(rs.next())
//            {
//                System.out.println(rs.getString(1));
//            }
//
//            con.close();
//
//        }
//        catch(Exception ex )
//        {
//            ex.printStackTrace();
//        }
//        finally
//        {
//            if(con!=null)
//            {
//                 con.close();
//            }
//        }
//    }
//    
//}