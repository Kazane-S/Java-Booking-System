package hsql_db;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class DeleteTable {
	public static void main(String[] args) throws SQLException {
		
		final String DB_NAME = "testDB";
		final String TABLE_NAME = "DATA";
		final String TABLE_NAME2 = "RECORD";
		
		//use try-with-resources Statement
		try (Connection con = ConnectionTest.getConnection(DB_NAME);
				Statement stmt = con.createStatement();
		) {
			int result = stmt.executeUpdate("DROP TABLE DATA");
			int result1 = stmt.executeUpdate("DROP TABLE RECORD");
			
			
			if(result == 0) {
				System.out.println("Table " + TABLE_NAME + " has been deleted successfully");
			} else {
				System.out.println("Table " + TABLE_NAME + " was not deleted");
			}
			
			if(result1 == 0) {
				System.out.println("Table " + TABLE_NAME2 + " has been deleted successfully");
			} else {
				System.out.println("Table " + TABLE_NAME2 + " was not deleted");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	
	public void DeleteTable2() {
		final String DB_NAME = "testDB";
		final String TABLE_NAME = "DATA";
		final String TABLE_NAME2 = "RECORD";
		
		//use try-with-resources Statement
		try (Connection con = ConnectionTest.getConnection(DB_NAME);
				Statement stmt = con.createStatement();
		) {
			int result = stmt.executeUpdate("DROP TABLE DATA");
			int result1 = stmt.executeUpdate("DROP TABLE RECORD");
			
			
			if(result == 0) {
				System.out.println("Table " + TABLE_NAME + " has been deleted successfully");
			} else {
				System.out.println("Table " + TABLE_NAME + " was not deleted");
			}
			
			if(result1 == 0) {
				System.out.println("Table " + TABLE_NAME2 + " has been deleted successfully");
			} else {
				System.out.println("Table " + TABLE_NAME2 + " was not deleted");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
}
