package hsql_db;
import java.sql.Connection;
import java.sql.Statement;
import java.io.*;

public class InsertRow {
	public static void main(String[] args) {
		final String DB_NAME = "testDB";
		final String TABLE_NAME = "DATA";
		final String TABLE_NAME2 = "RECORD";
		
		//use try-with-resources Statement
		try (Connection con = ConnectionTest.getConnection(DB_NAME);
				Statement stmt = con.createStatement();
		) {
//			String t1 = "A_001:001:Elizabeth Street:Jolimont:Apartment:1:Rented:1.jpg:description1";
//			String s[] = t1.split(":");
//					
//			String query = "INSERT INTO " + TABLE_NAME + 
//					" VALUES ('" + s[0] + "'," + s[1] + ",'" + s[2] + "','" + s[3] + "','" + s[4] + "'," + s[5] + ",'" + s[6] + "','" + s[7] + "','" + s[8] + "')";
//			
////			String query = "INSERT INTO " + TABLE_NAME + 
////					" VALUES ('A_001', 001, 'Elizabeth Street', 'Jolimont', 'Apartment', 1, 'Rented', '1.jpg', 'description1')";
//			
//			int result = stmt.executeUpdate(query);
//			con.commit();
//			System.out.println("Insert into Table " + TABLE_NAME + " executed successfully");
			
			
//			reading files
			
			try {
			
			BufferedReader br = new BufferedReader(new FileReader("myfiles/data.txt"));
			String next = br.readLine();
			
						
			while(next != null) {
				

				System.out.println(next);
				
//				insert rows to db
				
				String s[] = next.split(":");
				String s0[] = s[0].split("_");
				
				
//				insert to DATA table
				
				if(s0.length < 3) {
				
					String query = "INSERT INTO " + TABLE_NAME + 
							" VALUES ('" + s[0] + "'," + s[1] + ",'" + s[2] + "','" + s[3] + "','" + s[4] + "'," + s[5] + ",'" + s[6] + "','" + s[7] + "','" + s[8] + "')";
	
					stmt.executeUpdate(query);
					con.commit();
					
					System.out.println("Insert into Table " + TABLE_NAME + " executed successfully");
					
					next = br.readLine();
				}
				
				if(s0.length >= 3) {
									
					String query2 = "INSERT INTO " + TABLE_NAME2 + 
							" VALUES ('" + s[0] + "','" + s[1] + "','" + s[2] + "','" + s[3] + "'," + s[4] + "," + s[5] + ")";
					
					stmt.executeUpdate(query2);
					con.commit();
					
					System.out.println("Insert into Table " + TABLE_NAME2 + " executed successfully");
					
					next = br.readLine();	
					
				}
			
//			end of while loop	
				
			}
			
			br.close();
			
//			Error handling
			} catch(IOException e) {
				System.out.println("File Reading Error!");
				System.exit(0);
			}
			
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void InsertInitialRows() {
		final String DB_NAME = "testDB";
		final String TABLE_NAME = "DATA";
		final String TABLE_NAME2 = "RECORD";
		
		//use try-with-resources Statement
		try (Connection con = ConnectionTest.getConnection(DB_NAME);
				Statement stmt = con.createStatement();
		) {
	
			
//			reading files
			
			try {
			
			BufferedReader br = new BufferedReader(new FileReader("myfiles/data.txt"));
			String next = br.readLine();
			
						
			while(next != null) {
				

				System.out.println(next);
				
//				insert rows to db
				
				String s[] = next.split(":");
				String s0[] = s[0].split("_");
				
				
//				insert to DATA table
				
				if(s0.length < 3) {
				
					String query = "INSERT INTO " + TABLE_NAME + 
							" VALUES ('" + s[0] + "'," + s[1] + ",'" + s[2] + "','" + s[3] + "','" + s[4] + "'," + s[5] + ",'" + s[6] + "','" + s[7] + "','" + s[8] + "')";
	
					stmt.executeUpdate(query);
					con.commit();
					
					System.out.println("Insert into Table " + TABLE_NAME + " executed successfully");
					
					next = br.readLine();
				}
				
				if(s0.length >= 3) {
									
					String query2 = "INSERT INTO " + TABLE_NAME2 + 
							" VALUES ('" + s[0] + "','" + s[1] + "','" + s[2] + "','" + s[3] + "'," + s[4] + "," + s[5] + ")";
					
					stmt.executeUpdate(query2);
					con.commit();
					
					System.out.println("Insert into Table " + TABLE_NAME2 + " executed successfully");
					
					next = br.readLine();	
					
				}
			
//			end of while loop	
				
			}
			
			br.close();
			
//			Error handling
			} catch(IOException e) {
				System.out.println("File Reading Error!");
				System.exit(0);
			}
			
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void InsertRows2(String ir) {
		final String DB_NAME = "testDB";
		final String TABLE_NAME = "DATA";
		final String TABLE_NAME2 = "RECORD";
		
		//use try-with-resources Statement
		try (Connection con = ConnectionTest.getConnection(DB_NAME);
				Statement stmt = con.createStatement();
		) {
	
			System.out.println(ir);
			
//			insert rows to db
			
			String s[] = ir.split(":");
			String s0[] = s[0].split("_");
			
				
				
//			insert to DATA table
				
			if(s0.length < 3) {
				String query = "INSERT INTO " + TABLE_NAME + 
						" VALUES ('" + s[0] + "'," + s[1] + ",'" + s[2] + "','" + s[3] + "','" + s[4] + "'," + s[5] + ",'" + s[6] + "','" + s[7] + "','" + s[8] + "')";
	
				stmt.executeUpdate(query);
				con.commit();
					
				System.out.println("Insert into Table " + TABLE_NAME + " executed successfully");
			}
				
			if(s0.length >= 3) {
									
				String query2 = "INSERT INTO " + TABLE_NAME2 + 
						" VALUES ('" + s[0] + "','" + s[1] + "','" + s[2] + "','" + s[3] + "'," + s[4] + "," + s[5] + ")";
					
				stmt.executeUpdate(query2);
				con.commit();
					
				System.out.println("Insert into Table " + TABLE_NAME2 + " executed successfully");		
			}			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
}
