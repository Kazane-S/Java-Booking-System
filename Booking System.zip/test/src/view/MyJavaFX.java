package view;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.scene.control.Label;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.layout.*;
import javafx.scene.layout.GridPane;

import javafx.scene.Scene;
import javafx.scene.Group;
import javafx.scene.layout.HBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.application.Application;
import javafx.geometry.Insets;

import test.*;
import hsql_db.*;

public class MyJavaFX extends Application {
	public void start(Stage primaryStage) {
		
		VBox pane0 = new VBox(30);
        VBox pane1 = new VBox(30);
        VBox pane2 = new VBox(30);
        VBox pane3 = new VBox(30);   
        VBox pane4 = new VBox(30); 
        VBox pane5 = new VBox(30); 
        VBox pane6 = new VBox(30); 
                      
        Button go01 = new Button("Add Property");
        Button go02 = new Button("Rent Property");
        Button go03 = new Button("Return Property");
        Button go04 = new Button("Perform Maintenance");
        Button go05 = new Button("Complete Maintenancce");
        Button go06 = new Button("Display Details");
        
        Button go10 = new Button("Go to Main menu");
        Button go20 = new Button("Go to Main menu");
        Button go30 = new Button("Go to Main menu");
        Button go40 = new Button("Go to Main menu");
        Button go50 = new Button("Go to Main menu");
        Button go60 = new Button("Go to Main menu");
        
        pane0.getChildren().addAll(new Label("Menu: "), go01, go02, go03, go04, go05, go06);
        pane1.getChildren().addAll(new Label("Menu: "), go10);
        pane2.getChildren().addAll(new Label("Menu: "), go20);
        pane3.getChildren().addAll(new Label("Menu: "), go30);
        pane4.getChildren().addAll(new Label("Menu: "), go40);
        pane5.getChildren().addAll(new Label("Menu: "), go50);
        pane6.getChildren().addAll(new Label("Menu: "), go60);
        
        Scene scene0 = new Scene(pane0, 600, 600);
        Scene scene1 = new Scene(pane1, 600, 600);
        Scene scene2 = new Scene(pane2, 600, 600);
        Scene scene3 = new Scene(pane3, 600, 600);
        Scene scene4 = new Scene(pane4, 600, 600);
        Scene scene5 = new Scene(pane5, 600, 600);
        Scene scene6 = new Scene(pane6, 600, 600);
        
        
        go10.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                primaryStage.setScene(scene0);
            }
        });
        go20.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                primaryStage.setScene(scene0);
            }
        });
        go30.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                primaryStage.setScene(scene0);
            }
        });
        go40.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                primaryStage.setScene(scene0);
            }
        });
        go50.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                primaryStage.setScene(scene0);
            }
        });
        go60.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                primaryStage.setScene(scene0);
            }
        });
        go01.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                primaryStage.setScene(scene1);
            }
        });
        go02.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                primaryStage.setScene(scene2);
            }
        });
        go03.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                primaryStage.setScene(scene3);
            }
        });
        go04.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                primaryStage.setScene(scene4);
            }
        });
        go05.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                primaryStage.setScene(scene5);
            }
        });
        go06.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                primaryStage.setScene(scene6);
            }
        });
        
        primaryStage.setScene(scene0);
        primaryStage.show();
	}
}

class AddProperty implements EventHandler<ActionEvent> {	
	public void handle(ActionEvent e) {
		System.out.println("Left button clicked");
	}
}

class RentProperty implements EventHandler<ActionEvent> {
	public void handle(ActionEvent e) {
		System.out.println("Right button clicked");
	}
}

class ReturnProperty implements EventHandler<ActionEvent> {
	public void handle(ActionEvent e) {
		System.out.println("Right button clicked");
	}
}

class PerformMaintenance implements EventHandler<ActionEvent> {
	public void handle(ActionEvent e) {
		System.out.println("Right button clicked");
	}
}

class CompleteMaintenance implements EventHandler<ActionEvent> {
	public void handle(ActionEvent e) {
		System.out.println("Right button clicked");
	}
}

class DisplayProperty implements EventHandler<ActionEvent> {
	public void handle(ActionEvent e) {
		System.out.println("Right button clicked");
	}
}

class Quit implements EventHandler<ActionEvent> {
	public void handle(ActionEvent e) {
		System.out.println("Right button clicked");
	}
}


class SquaresPane extends GridPane {
	public SquaresPane(int rows, int cols) {
		for (int i = 0; i < rows; i++)
			for (int j = 0; j < cols; j++)
				add(new Button("row=" + i + " col=" + j), j, i);

	}
}